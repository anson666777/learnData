# encoding: utf-8

# 第一題：实现一个函数，用于求两个数之和。
# def add(a,b):
# 	print(a+b)
# add(1,2)

# 第二题：实现一个函数，可以求任意多个数之和。
# def add(*args):
# 	result = 0
# 	for arg in args:
# 		result += arg
# 	print('结果是：%s'%result)


# ========================================
# 第三题：将第七天的学生管理系统，用函数模块化。
print("欢迎来到知了学生管理系统！")

students = []

def add_student():
	print("请输入学生信息")
	name = input("姓名：")
	gender = input('性别：')
	age = input('年龄：')
	classroom = input('班级：')
	student = {"name":name,"gender":gender,"age":age,"classroom":classroom}
	students.append(student)
	print("恭喜！学生添加成功！")


def list_student():
	print("以下是所有学生信息：")
	for student in students:
		name = student['name']
		gender = student['gender']
		classroom = student['classroom']
		print("姓名：%s，性别：%s，班级：%s"%(name,gender,classroom))


def search_student():
	name = input("请输入学生姓名：")
	for student in students:
		if student['name'] == name:
			name = student['name']
			gender = student['gender']
			classroom = student['classroom']
			print("姓名：%s，性别：%s，班级：%s"%(name,gender,classroom))


def main():
	while True:
		print("="*20)
		print("1. 新增学生")
		print("2. 列出所有学生")
		print("3. 根据姓名查找学生")
		print("="*20)
		opt = input("请输入你要的序号：")
		if not opt.isdigit() or opt not in ['1','2','3']:
			print("序号输入不正确！")
			continue
		else:
			if opt == '1':
				add_student()
			elif opt == '2':
				list_student()
			else:
				search_student()


if __name__ == '__main__':
	main()