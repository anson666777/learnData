# encoding: utf-8


# 一、第一大题：
text = """I am xiaoxiao,I have over 8 years of experience in marketing. I am the team manager of marketing for HP since 2013"""
# 1. 把以上字符串的所有空格删掉，并保存在另外一个新的字符串中。
text_new = text.replace(" ",'')
print(text_new)


# 2. 判断以上单词的个数。
word_new = text.split(" ")
word_count = len(word_new)
print(word_count)


# 3. 把以上所有以 t（不区分大小写）开头的单词都找出来。
words = text.split(" ")
for word in words:
	word_lower = word.lower()
	if word_lower.startswith("t"):
		print(word)

# 4. 把以上所有的数字都找出来。
words = text.replace(",","").replace(".","").split(" ")
for word in words:
	if word.isdigit():
		print(word)

# ======================================================
# 第二大题：把以下变量用format函数写一个连接数据库的语句。
用户名
DB_USERNAME = 'root'
# 密码
DB_PASSWORD = 'root'
# 主机
DB_HOST = '127.0.0.1'
# 端口号
DB_PORT = 3306
# 数据库名字
DB_NAME = 'zhiliao'

URI = "mysql+pymysql://{username}:{password}@{host}:{port}/{dbname}?charset=utf8".format(username=DB_USERNAME,password=DB_PASSWORD,host=DB_HOST,port=DB_PORT,dbname=DB_NAME)
print(URI)