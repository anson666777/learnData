# encoding: utf-8


print("欢迎来到知了学生管理系统！")

def add_student():
	print("请输入学生信息")
	name = input("姓名：")
	gender = input('性别：')
	age = input('年龄：')
	classroom = input('班级：')
	student = "{},{},{},{}".format(name,gender,age,classroom)
	with open('students.txt','w') as fp:
		fp.writelines([student])
	print("恭喜！学生添加成功！")


def list_student():
	print("以下是所有学生信息：")
	with open('students.txt','r') as fp:
		for line in fp:
			infos = line.split(",")
			name = infos[0]
			gender = infos[1]
			age = infos[2]
			classroom = infos[3]
			print("姓名：%s，性别：%s，年龄：%s，班级：%s" % (name,gender,age,classroom))


def search_student():
	name_value = input("请输入学生姓名：")
	with open("students.txt",'r') as fp:
		for line in fp:
			infos = line.split(",")
			name = infos[0]
			if name == name_value:
				gender = infos[1]
				age = infos[2]
				classroom = infos[3]
				print("姓名：%s，性别：%s，年龄：%s，班级：%s" % (name,gender,age,classroom))

def main():
	while True:
		print("="*20)
		print("1. 新增学生")
		print("2. 列出所有学生")
		print("3. 根据姓名查找学生")
		print("="*20)
		opt = input("请输入你要的序号：")
		if not opt.isdigit() or opt not in ['1','2','3']:
			print("序号输入不正确！")
			continue
		else:
			if opt == '1':
				add_student()
			elif opt == '2':
				list_student()
			else:
				search_student()


if __name__ == '__main__':
	main()