#coding: utf-8

# 第一题：给以下列表做逆序操作：a = [1,2,3,4,5,6,7,8,9]。
# a = [1,2,3,4,5,6,7,8,9]
# a_reversed = a[::-1]
# print(a_reversed)


#===============================================
# 第二题：
# 实现一个学生管理系统。要求如下：
# * 要求记录学生的学号，姓名，年龄，所属班级信息。
# * 学号是自动增长的。（比如第一个添加进去的学号是 1，第二个添加进去的
# 学号是 2）
# * 可以新增学生。
# * 可以列出所有学生。
# * 可以根据学号或者姓名查找学生。
# * 可以根据学号删除学生。
# * 提示：用字典存储一个学生的信息，用列表存储所有学生的字典对象。

print("欢迎来到知了学生管理系统！")

students = []

while True:
	print("="*20)
	print("1. 新增学生")
	print("2. 列出所有学生")
	print("3. 根据姓名查找学生")
	print("="*20)
	opt = input("请输入你要的序号：")
	if not opt.isdigit() or opt not in ['1','2','3']:
		print("序号输入不正确！")
		continue
	else:
		if opt == '1':
			print("请输入学生信息")
			name = input("姓名：")
			gender = input('性别：')
			age = input('年龄：')
			classroom = input('班级：')
			student = {"name":name,"gender":gender,"age":age,"classroom":classroom}
			students.append(student)
			print("恭喜！学生添加成功！")
		elif opt == '2':
			print("以下是所有学生信息：")
			for student in students:
				name = student['name'].decode("gbk")
				gender = student['gender'].decode("gbk")
				classroom = student['classroom'].decode("gbk")
				print("姓名：%s，性别：%s，班级：%s"%(name,gender,classroom))
		else:
			name = input("请输入学生姓名：")
			for student in students:
				if student['name'] == name:
					name = student['name'].decode("gbk")
					gender = student['gender'].decode("gbk")
					classroom = student['classroom'].decode("gbk")
					print("姓名：%s，性别：%s，班级：%s"%(name,gender,classroom))
