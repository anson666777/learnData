# 1. 实现一个加法计算器，可以接收用户输入的两个数据，然后计算其相加的结果。
value1 = input("请输入值1：")
value2 = input('请输入值2：')
result = float(value1) + float(value2)
print(result)

# 2. 有变量a='12.3'，想要将其转换为整形，可以怎么做？
a = '12.3'
b = float(a)
c = int(c)
print(c)