# 1. 计算体脂率：
# gender：性别
gender = raw_input(u"请输入性别（男或女）：".encode("gbk"))
# waistline：腰围
waistline = raw_input(u'请输入腰围（cm）：'.encode("gbk"))
# weight：体重
weight = raw_input(u'请输入体重（kg）：'.encode("gbk"))

arg = 0

if gender == '女'：
	arg = 34.89
elif gender == '男':
	arg = 44.74

a = waistline * 0.74
b = weight * 0.082 + arg
fat_weight = a - b
fa_rate = (fat_weight / weight) * 100
print(fa_rate)


# 2. for循环版本的99乘法表：
for row in range(1,10):
	for col in range(1,row+1):
		print("%s*%s=%s"%(col,row,col*row))
	print("")

# 3. 找出1000以内的水仙花数。
# 100 - 999
# 153 = 1^3 + 5^3 + 3^3
# 第一种解决办法：
for x in range(100,1000):
	a = x // 100
	b = (x % 100)//10
	c = x - a*100 - b*10
	if x == a**3 + b**3 + c**3:
		print(x)

# 第二种解决办法：
for x in range(100,1000):
	x_str = str(x)
	# "153"
	a = int(x_str[0]) #1 
	b = int(x_str[1]) #5
	c = int(x_str[2]) #3
	if x == a**3 + b**3 + c**3:
		print(x)