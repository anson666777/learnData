#encoding: utf-8


class Person(object):
    def __init__(self,name,age,height):
        self.name = name
        self.age = age
        self.height = height

    def __ne__(self, other):
        # self != other
        return False if self.age == other.age and self.height == other.height else True

    def __eq__(self, other):
        # self == other
        if self.age == other.age:
            if self.height == other.height:
                return True
            else:
                return True if self.height == other.height else False

    def __lt__(self, other):
        # self < other
        if self.age == other.age:
            return True if self.height < other.height else False
        return self.age < other.age

    def __gt__(self, other):
        # self > other
        if self.age == other.age:
            return True if self.height > other.height else False
        return self.age > other.age

    def __cmp__(self, other):
        if self.age == other.age:
            if self.height == self.height:
                return 0
            else:
                return 1 if self.height > other.height else -1
        return 1 if self.age > other.age else -1



p1 = Person('zhiliao1',18,180)
p2 = Person('zhiliao2',18,180)
# print(p1>=p2)

print(p1.__dict__)

