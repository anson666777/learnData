#encoding: utf-8
from __future__ import division

class Coornidate(object):
    def __init__(self,x,y):
        self.x = x
        self.y = y

    def __add__(self, other):
        new_coornidate = Coornidate(self.x+other.x,self.y+other.y)
        return new_coornidate

    def __sub__(self, other):
        new_coornidate = Coornidate(self.x-other.x,self.y-other.y)
        return new_coornidate

    def __mul__(self, other):
        new_coornidate = Coornidate(self.x*other.x,self.y*other.y)
        return new_coornidate

    def __floordiv__(self, other):
        new_coornidate = Coornidate(self.x//other.x,self.y//other.y)
        return new_coornidate

    def __div__(self, other):
        new_coornidate = Coornidate(self.x/other.x,self.y/other.y)
        return new_coornidate

    def __truediv__(self, other):
        new_coornidate = Coornidate(self.x/other.x,self.y/other.y)
        return new_coornidate

    def __mod__(self, other):
        new_coornidate = Coornidate(self.x%other.x,self.y%other.y)
        return new_coornidate

    def __str__(self):
        return "(%s,%s)" % (self.x,self.y)


c1 = Coornidate(4,6)
c2 = Coornidate(3,4)
c3 = c1+c2
c4 = c1 - c2
c5 = c1*c2
c6 = c1/c2
c7 = c1%c2
print(c7)