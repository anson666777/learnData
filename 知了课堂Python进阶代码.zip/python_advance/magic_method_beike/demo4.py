#encoding: utf-8
from __future__ import division

class Coornidate(object):
    def __init__(self,x,y):
        self.x = x
        self.y = y

    def __iadd__(self, other):
        self.x += other
        self.y += other
        return self

    def __isub__(self, other):
        new_coordinate = Coornidate(self.x-other,self.y-other)
        return new_coordinate

    def __imul__(self, other):
        new_coordinate = Coornidate(self.x*other,self.y*other)
        return new_coordinate

    def __itruediv__(self, other):
        new_coordinate = Coornidate(self.x/other,self.y/other)
        return new_coordinate

    def __str__(self):
        return "(%s,%s)" % (self.x,self.y)


c1 = Coornidate(4,6)
# c1 += 1
# c1 -= 1
# c1 *= 1
# c1 /= 2
print(c1)