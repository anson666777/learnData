#encoding: utf-8

class FileOpener(object):
    def __init__(self,*args,**kwargs):
        self.args = args
        self.kwargs = kwargs

    def __enter__(self):
        self.fp = open(*self.args,**self.kwargs)
        return self.fp

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.fp.close()
        print(exc_type)
        return False


with FileOpener('test.txt','r') as fp:
    a = 1
    b = 0
    # c = a/b
    print(fp.read())
