#encoding: utf-8

import pickle

class Person(object):
    def __init__(self,name,age):
        self.name = name
        self.age = age

    def __getstate__(self):
        return {"name":self.name,"age":self.age}

    def __setstate__(self, state):
        self.name = state['name']
        self.age = state['age']

# p1 = Person('zhiliao',18)
# fp = open('xxx.pkl','w')
# pickle.dump(p1,fp)

fp = open('xxx.pkl','r')
p1 = pickle.load(fp)
print(p1.name)
print(p1.age)