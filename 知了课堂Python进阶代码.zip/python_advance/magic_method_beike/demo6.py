#encoding: utf-8

class ZLList(object):
    def __init__(self,values=None):
        if values is None:
            self.values = []
        else:
            self.values = values

    def __iter__(self):
        return iter(self.values)

    def __len__(self):
        return len(self.values)

    def __getitem__(self, item):
        return self.values[item]

    def __setitem__(self, key, value):
        self.values[key] = value

    def __delitem__(self, key):
        del self.values[key]

    def __reversed__(self):
        return reversed(self.values)

    def append(self,value):
        self.values.append(value)

    def remove(self,value):
        return self.values.remove(value)

    def head(self):
        return self.values[0]

    def tail(self):
        return self.values[-1]

    def take(self,n):
        return self.values[:n]


a = ZLList()
a.append('hello')
a.append('world')
# print(len(a))
# for x in a:
#     print(x)
a[0] = 'zhiliao'
print(a[0])