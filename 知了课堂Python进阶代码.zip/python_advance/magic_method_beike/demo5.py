#encoding: utf-8

class Person(object):
    def __init__(self,name):
        self.name = name

    def __setattr__(self, key, value):
        if key == 'age':
            self.__dict__[key] = value
            if value >= 18:
                self.__dict__['is_adult'] = True
            else:
                self.__dict__['is_adult'] = False
        else:
            self.__dict__[key] = value
            
    def __getattribute__(self, item):
        print(item)
        return super(Person, self).__getattribute__(item)


p1 = Person('zhiliao')
p1.name = 'zhiliao'
p1.age = 18