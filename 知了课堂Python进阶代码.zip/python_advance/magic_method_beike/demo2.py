#encoding: utf-8

class Coornidate(object):
    def __init__(self,x,y):
        self.x = x
        self.y = y

    def __pos__(self):
        return self

    def __neg__(self):
        new_coornidate = Coornidate(-self.x,-self.y)
        return new_coornidate

    def __abs__(self):
        new_coornidate = Coornidate(abs(self.x),abs(self.y))
        return new_coornidate

    def __invert__(self):
        new_coornidate = Coornidate(255-self.x,255-self.y)
        return new_coornidate

    def __str__(self):
        return "(%s,%s)" % (self.x,self.y)


c1 = Coornidate(-1,2)
c2 = +c1
c3 = -c1
c4 = abs(c1)
c5 = ~c1
print(c5)