#encoding: utf-8

class MyRangeIterator(object):
    """
    迭代器
    """
    def __init__(self,start,end):
        self.index = start
        self.end = end

    def __next__(self):
        if self.index < self.end:
            index = self.index
            self.index += 1
            return index
        else:
            raise StopIteration()


class MyRange(object):
    """
    可迭代对象
    """
    def __init__(self,start,end):
        self.start = start
        self.end = end

    def __iter__(self):
        return MyRangeIterator(self.start,self.end)


# 初始化一个可迭代的对象
# for x in MyRange(1,10):
#     print(x)

# 使用itre函数将可迭代的对象转换为迭代器
range_iterator = iter(MyRange(1,10))

# 不能遍历迭代器，只能通过next来迭代
for x in range_iterator:
    print(x)