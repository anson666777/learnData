#encoding: utf-8
from collections import Iterable,Iterator
import time
import random
from urllib.request import urlretrieve

# def Consumer(url):
#     while True:
#         if url:
#             filename = url.split('/').pop()
#             url = yield urlretrieve(url,filename='images/'+filename)
#             print('consumer')
#
#
# def Producter(consumer):
#     # 先执行一下，让后面的send不会报错
#     index = 2
#     next(consumer)
#     while index < 10:
#         print('生产者已经获取了第%d个图片链接' % index)
#         url = 'http://127.0.0.1:9000/%d.jpg' % index
#         consumer.send(url)
#         print('producter')
#         index += 1
#
#     consumer.close()
#
# con = Consumer("http://127.0.0.1:9000/1.jpg")
# Producter(con)


def neteasy_music(duration):
    c_time = 0
    while c_time < duration:
        print('播放音乐 %d分钟'%c_time)
        yield None
        c_time += 1

def youku_movie(duration):
    c_time = 0
    while c_time < duration:
        print('播放电影 %d分钟' % c_time)
        yield None
        c_time += 1

def main():
    music = neteasy_music(10)
    qq = youku_movie(10)
    music_stop = False
    movie_stop = False
    while True:
        try:
            next(music)
        except StopIteration:
            print('音乐播放完毕')
            music_stop = True

        try:
            next(qq)
        except StopIteration:
            print('电影播放完毕')
            movie_stop = True

        if music_stop and movie_stop:
            break

if __name__ == '__main__':
    main()