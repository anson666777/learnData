#encoding: utf-8

# gc.get_threshold()：获取每个链表遍历的阈值
# gc.set_threshold()：设置每个链表遍历的阈值
# gc.get_count()：获取每个链表当前的计数
# gc.collect()：手动的回收每条链表的垃圾
# 开发者自己写了__del__函数，如果发生循环引用了，将不能回收
# gc.set_debug：设置是否gc的debug模式

import gc

class Person(object):
    def __init__(self,name):
        self.name = name
        self.pointer = None

    def __del__(self):
        print('%s 被回收了' % self.name)


# print(gc.get_threshold())
# gc.set_threshold(500)
# print(gc.get_threshold())

gc.set_debug(gc.DEBUG_LEAK)

while True:
    print(gc.get_count())
    p1 = Person('p1')
    p2 = Person('p2')

    # 产生循环引用
    p1.pointer = p2
    p2.pointer = p1

    del p1
    del p2

    a = input('test:')
    gc.collect(1)