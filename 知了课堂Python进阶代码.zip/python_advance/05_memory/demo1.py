#encoding: utf-8

# 引用计数
class Person(object):
    def __init__(self,name):
        self.name = name
        self.next = None
        self.prev = None

    def __del__(self):
        print('%s被释放掉了'%self.name)

while True:
    p1 = Person('p1')
    p2 = Person('p2')
    p1.next = p2
    p2.prev = p1
    # temp1 = p1
    del p1
    del p2
    a = input('test:')

