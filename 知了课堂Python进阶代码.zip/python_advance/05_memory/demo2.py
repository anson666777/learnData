#encoding: utf-8

import sys

class Person(object):
    def __init__(self,name):
        self.name = name
        self.next = None
        self.prev = None

p1 = Person('p1')
p2 = Person('p2')
p3 = Person('p3')
p4 = Person('p4')

p1.next = p2
p2.prev = p1

temp1 = p3
temp2 = p4

del p1
del p2
del p3
del p4
del temp1
del temp2

print(sys.getrefcount(p1))
print(sys.getrefcount(p2))
print(sys.getrefcount(p3))
print(sys.getrefcount(p4))

A = 'xxx'

def greet():
    temp = 'hello'
    print(temp)


# 零代链表中：
# create_count：创建的对象
# delete_count：被释放的对象
# create_count - delete_count >= 700

# 如果零代链表遍历的次数超过了10次（这个值是Python默认的）
# 就会去遍历一代链表
# 会将循环引用的对象释放掉，然后将那些没有被释放掉的对象挪动到二代链表

# 如果一代链表的遍历次数超过了10次（这个值也是Python默认的）
# 就会去遍历二代链表