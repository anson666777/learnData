#encoding: utf-8

user = {
    "is_login": True
}

def login_required(func):
    def wrapper(*args,**kwargs):
        if user['is_login'] == True:
            func(*args,**kwargs)
        else:
            print('跳转到登录页面')
    return wrapper


@login_required
def edit_user(username):
    print('用户名修改成功：%s' % username)

edit_user('zhiliao')
login_required(edit_user)('zhiliao')

@login_required
def add_article(title,content):
    print('添加文章成功')

add_article('title','content')
# login_required(add_article)('title','content')
# wrapper('title','content')




