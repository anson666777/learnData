#encoding: utf-8
from functools import wraps

user = {
    'is_login': True
}

def login_required(func):
    @wraps(func)
    def wrapper(*args,**kwargs):
        if user['is_login'] == True:
            return func(*args,**kwargs)
        else:
            print('没有登录，跳转到首页')
    return wrapper

class Flask(object):
    def __init__(self):
        self.url_view_maps = {}

    def route(self,url):
        def outter_wrapper(func):
            self.url_view_maps[url] = func.__name__
            @wraps(func)
            def inner_wrapper(*args,**kwargs):
                func(*args,**kwargs)
            return inner_wrapper
        return outter_wrapper

    def run(self):
        while True:
            url = input('请输入网址：')
            view_func = self.url_view_maps.get(url)
            if view_func:
                exec(view_func+"()")
            else:
                print('抱歉，您访问的页面不存在')

app = Flask()

@app.route('/')
def index():
    print('index page')

@app.route('/list/')
def article_list():
    print('article list')

@app.route('/edit/')
@login_required
def edit_user():
    print('更改用户名成功~！')



if __name__ == '__main__':
    app.run()