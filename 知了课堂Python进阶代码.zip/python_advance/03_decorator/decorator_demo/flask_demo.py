#encoding: utf-8
from functools import wraps

class Flask(object):
    url_view_maps = {}
    def route(self,url):
        def outter_wrapper(func):
            self.url_view_maps[url] = func.__name__
            @wraps(func)
            def inner_wrapper(*args,**kwargs):
                func(*args,**kwargs)
            return inner_wrapper
        return outter_wrapper

    def run(self):
        while True:
            url = input('请输入网址：')
            view_func = self.url_view_maps.get(url)
            if view_func:
                exec("index()")
            else:
                print('url不存在，404错误')

app = Flask()

@app.route('/')
def index():
    print('index page')

@app.route('/list/')
def list_view():
    print('list view')


if __name__ == '__main__':
    app.run()

