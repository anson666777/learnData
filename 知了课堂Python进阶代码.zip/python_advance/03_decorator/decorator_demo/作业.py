
def linear(a,b):
	def inner(x,y):
		return a*x + b*y

func1 = linear(1,1)
func(1,2)

func2 = linear(2,2)
func(1,2)

