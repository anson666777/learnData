#encoding: utf-8

user = {
    "is_login": False
}

# def login_required(func):
#     def wrapper(*args,**kwargs):
#         if user['is_login'] == True:
#             func(*args,**kwargs)
#         else:
#             if 'front':
#                 print('跳转到登录页面')
#             else:
#                 print('跳转到后台登录页面')
#     return wrapper

# def login_required(site='front'):
#     def wrapper(*args,**kwargs):
#         if user['is_login'] == True:
#

def login_required(site='front'):
    def outter_wrapper(func):
        def inner_wrapper(*args,**kwargs):
            if user['is_login'] == True:
                func(*args,**kwargs)
            else:
                if site == 'front':
                    print('跳转到前台的登录页面')
                else:
                    print('跳转到后台的登录页面')
        return inner_wrapper
    return outter_wrapper


@login_required()
def edit_user(username):
    print('用户名修改成功：%s' % username)

edit_user('zhiliao')