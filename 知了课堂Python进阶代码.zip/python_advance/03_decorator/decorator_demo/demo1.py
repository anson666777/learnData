#encoding: utf-8

# def greet(name):
#     print('outter')
#     def say_hello():
#         print('hello my name is %s' % name)
#     return say_hello
#
# ret = greet('zhiliao')
# ret()

# 用一个函数实现加、减、乘、除的计算器

# 1：代表加
# 2. 代表减
# 3. 代表乘
# 4. 代表除

# def calculator(x,y,operator):
#     if operator == 1:
#         return x+y
#     elif operator == 2:
#         return x-y
#     elif operator == 3:
#         return x*y
#     elif operator == 4:
#         return x/y
#     else:
#         print('操作符不正确')
#
# ret = calculator(1,2,1)
# ret = calculator(2,2,1)
# ret = calculator(3,2,1)
# ret = calculator(4,2,1)
# print(ret)

# def calculator(option):
#     if option == 1:
#         def add(x,y):
#             return x+y
#         return add
#     elif option == 2:
#         def minus(x,y):
#             return x-y
#         return minus
#     elif option == 3:
#         def multiply(x,y):
#             return x*y
#         return multiply
#     elif option == 4:
#         def divide(x,y):
#             return x/y
#         return divide
#     else:
#         print('操作符不正确')
#         return None
#
# add = calculator(1)
# ret = add(1,2)
# print(ret)
#
# multipy = calculator(3)
# ret = multipy(1,2)
# print(ret)

# NUM = 10
#
# def add():
#     global NUM
#     NUM += 1
#     print(NUM)
#
# add()

# def greet(name):
#     print('outter name is:%s' % name)
#     def say_hello():
#         nonlocal name
#         name += ' ketang'
#         print('inner name is %s' % name)
#
#     return say_hello
#
# # ret = greet('zhiliao')
# # ret()
# greet('zhiliao')()
