#encoding: utf-8

user = {
    "is_login": False
}

def case1():
    def edit_user():
        if user['is_login'] == True:
            print('用户名修改成功')
        else:
            print('跳转到登录页面')

    def add_article():
        if user['is_login'] == True:
            print('添加文章成功')
        else:
            print('跳转到登录页面')

    edit_user()
    add_article()

def case2():
    def login_required(func):
        if user['is_login'] == True:
            func()
        else:
            print('跳转到登录页面')

    def edit_user():
        print('用户名修改成功')

    def add_article():
        print('添加文章成功')


    login_required(edit_user)

def case3():
    # def login_required(func):
    #     if user['is_login'] == True:
    #         func()
    #     else:
    #         print('跳转到登录页面')

    def login_required(func):
        def wrapper():
            if user['is_login'] == True:
                func()
            else:
                print('跳转到登录页面')
        return wrapper

    @login_required
    def edit_user():
        print('用户名修改成功')

    def add_article():
        print('添加文章成功')

    # login_required(edit_user)()

    class Person(object):

        @login_required
        def greet(self):
            print('hello')

    p = Person()
    p.greet()

    edit_user()

case3()