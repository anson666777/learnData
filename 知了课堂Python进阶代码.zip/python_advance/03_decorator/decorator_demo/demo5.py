#coding: utf-8
from functools import wraps

def greet(func):

    @wraps(func)
    def wrapper(*args,**kwargs):
        print('func start exec')
        func(*args,**kwargs)
        print('func end exec')
    return wrapper

@greet
def add(x,y):
    print('%d+%d=%d' % (x,y,x+y))

print(add.__name__)