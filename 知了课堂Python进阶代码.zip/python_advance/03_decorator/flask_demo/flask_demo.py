from flask import Flask

app = Flask(__name__)

# www.baidu.com
# url_maps = {'/':hello_world}
@app.route('/')
def hello_world():
    return 'Hello World!'

@app.route('/list/')
def article_list():
    return 'article list'

if __name__ == '__main__':
    app.run()
