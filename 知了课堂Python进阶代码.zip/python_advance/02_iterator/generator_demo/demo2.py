#encoding: utf-8


def my_gen(start):
    while start < 10:
        # 如果是通过next函数执行yield
        # 那么yield xxx 永远都是返回None
        temp = yield start
        print(temp)
        start += 1

ret = my_gen(1)
print(ret.send(None))
print(next(ret))
# 1
print(next(ret))
# temp
# 2
print(ret.send('zhiliao'))
# zhiliao
# 3
