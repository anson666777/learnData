#encoding: utf-8

# 实现一个简单的协程
import time


def download_image(url):
    duration = 2
    start_time = time.time()
    end_time = start_time + 3
    while True:
        current_time = time.time()
        if current_time >= end_time:
            print('图片%s下载完成！'%url)
            break
        else:
            yield None

def main():
    one_iter = download_image(1)
    two_iter = download_image(2)
    three_iter = download_image(3)
    four_iter = download_image(4)
    five_iter = download_image(5)
    while True:
        next(one_iter)
        next(two_iter)
        next(three_iter)
        next(four_iter)
        next(five_iter)

if __name__ == '__main__':
    main()