#encoding: utf-8

# 普通列表产生1到1亿的问题是不行的
# ret = [x for x in range(1,100000000)]
# for x in ret:
#     print(x)

# 生成器解决1到1亿的问题
# ret = (x for x in range(1,100000000))
# print(type(ret))

# 自定义生成器
# def my_gen():
#     yield 1
#     yield 2
#     yield 3
#
# ret = my_gen()
# print(type(ret))
# print(next(ret))
# print(next(ret))
# print(next(ret))
# print(next(ret))

def my_gen(start,end):
    index = start
    while index <= end:
        yield index
        index += 1

# 生成器有两个身份：迭代器和可迭代的对象
ret = my_gen(1,100000000)
for x in ret:
    print(x)