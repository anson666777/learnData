#encoding: utf-8

# def my_gen():
#     print('hello')
#     yield 1
#     return
#     print('world')
#     yield 2
#
# ret = my_gen()
# next(ret)
# next(ret)

# 斐波拉契数列
# def fib(count):
#     index = 1
#     a,b = 0,1
#     while index <= count:
#         yield b
#         c = b
#         b = a + b
#         a = c
#
#         index += 1
#
# for x in fib(7):
#     print(x)


def neteasy_music(duration):
    time = 0
    while time <= duration:
        print('歌曲听到了第%d分钟了' % time)
        time += 1
        yield None
    raise StopIteration()


def youku_movie(duration):
    time = 0
    while time <= duration:
        print('电影看到第%d分钟了'%time)
        time += 1
        yield None
    raise StopIteration()


def main():
    music_iter = neteasy_music(10)
    movie_iter = youku_movie(20)
    music_stop = False
    movie_stop = False
    while True:
        try:
            next(music_iter)
        except StopIteration:
            print('音乐已经播放完毕')
            music_stop = True

        try:
            next(movie_iter)
        except StopIteration:
            print('电影看完了')
            movie_stop = True

        if music_stop and movie_stop:
            break

if __name__ == '__main__':
    main()



