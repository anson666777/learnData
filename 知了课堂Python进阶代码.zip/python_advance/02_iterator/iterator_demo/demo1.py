#encoding: utf-8

from collections import Iterable,Iterator

# ret = [1,2,3]
# print(isinstance(ret,Iterable))

# ret = (1,2,3)
# print(isinstance(ret,Iterable))

# ret = "abc"
# print(isinstance(ret,Iterable))

# ret = 123
# print(isinstance(ret,Iterable))

# 判断一个对象是否是可迭代对象
# class MyRange(object):
#     def __iter__(self):
#         pass
#
# ret = MyRange()
# print(isinstance(ret,Iterable))

# 判断一个对象是否是迭代器对象
# class MyRange(object):
#     def __iter__(self):
#         pass
#
#     def __next__(self):
#         pass
#
# ret = MyRange()
# print(isinstance(ret,Iterator))

# 自定义一个可以用for循环遍历的类
# 类似于list或者是类似于range的对象
# range(1,10)

class MyRangeIterator(object):
    def __init__(self,start,end):
        self.index = start
        self.end = end

    def __iter__(self):
        return self

    def __next__(self):
        if self.index < self.end:
            temp = self.index
            self.index += 1
            return temp
        else:
            raise StopIteration()

class MyRange(object):
    """
    MyRange是可迭代对象
    """
    def __init__(self,start,end):
        self.start = start
        self.end = end

    def __iter__(self):
        # 这个方法中要返回一个迭代器对象
        return MyRangeIterator(self.start,self.end)


ret = MyRange(1,10)
for x in ret:
    print(x)
print('='*30)
for y in ret:
    print(y)


# for...in...的原理
# ret_iterator = iter(ret)
# while True:
#     try:
#         x = ret_iterator.__next__()
#         print(x)
#     except StopIteration:
#         break




# class MyRange(object):
#     """
#     MyRange是可迭代对象
#     """
#     def __init__(self,start,end):
#         self.start = start
#         self.end = end
#         self.index = start
#
#     def __iter__(self):
#         # 这个方法中要返回一个迭代器对象
#         return self
#
#     def __next__(self):
#         if self.index < self.end:
#             temp = self.index
#             self.index += 1
#             return temp
#         else:
#             raise StopIteration()
#
# my_range = MyRange(1,10)
# for x in my_range:
#     print(x)
#
# print('='*10)
# for y in my_range:
#     print(y)