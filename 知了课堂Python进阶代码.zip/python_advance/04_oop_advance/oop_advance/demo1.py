#encoding: utf-8
import types

# 动态添加属性
# class Person(object):
#     def __init__(self,name):
#         self.name = name
#
# p = Person('zhiliao')
# if hasattr(p,'country'):
#     print(True)
# else:
#     print(False)
# setattr(p,"age",20)
# print(p.age)

# 动态添加实例方法：
# class Person(object):
#     def __init__(self,name):
#         self.name = name
#
# p1 = Person('p1')
# p2 = Person('p2')
#
# def run(self):
#     print('%s 在奔跑' % self.name)
#
# p1.run = types.MethodType(run,p1)
# p1.run()

# 动态添加类方法：
# class Person(object):
#     country = 'china'
#     def __init__(self,name):
#         self.name = name
#
# @classmethod
# def run(cls):
#     print("%s 在奔跑" % cls.country)
#
# Person.run = run
# Person.run()

# 动态添加静态方法：
# class Person(object):
#     country = 'china'
#     def __init__(self,name):
#         self.name = name
#
# @staticmethod
# def run():
#     print('正在奔跑')
#
# Person.run = run
# Person.run()

# 动态删除属性
# class Person(object):
#     country = 'china'
#     def __init__(self,name):
#         self.name = name
#
# p1 = Person('zhiliao')
# print(p1.name)
# # del p1.name
# delattr(p1,'name')
# print(p1.name)

# __slots__魔术变量
class Person(object):
    __slots__ = ('name','age')
    def __init__(self,name):
        self.name = name

p1 = Person('zhiliao')
print(p1.name)
p1.age = 18
print(p1.age)
p1.country = 'china'
print(p1.country)