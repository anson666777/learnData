#encoding: utf-8

# def create_class(name):
#     if name == 'person':
#         class Person(object):
#             pass
#         return Person
#     else:
#         class Car(object):
#             pass
#         return Car
#
# MyClass = create_class('car')
# print(MyClass)


# 使用type动态创建类
# 创建一个类，叫做Peron，让她继承自object，需要有name和age属性
# Person = type("Person",(object,),{'name':"zhiliao",'age':18})
# print(Person)
# p = Person()
# print(p.age)


# age = 35
# print(age.__class__.__class__)
# name = 'zhiliao'
# print(name.__class__.__class__)
# def abc():
#     pass
# print(abc.__class__.__class__)
# class MyObject(object):
#     pass
# print(MyObject.__class__)



# def upper_attr_metaclass(class_name,parent_tuple,class_attrs):
#     new_attrs = [(k,v) for k,v in class_attrs.items() if not k.startswith("__") and not k.endswith("__")]
#     upper_attrs = dict((k.upper(),v) for k,v in new_attrs)
#     print(upper_attrs)
#     return type(class_name,parent_tuple,upper_attrs)
#
# class Person(object):
#     __metaclass__ = upper_attr_metaclass
#     country = 'china'
#
# print(Person.COUNTRY)

class UpperAttrsMetaClass(type):
    def __new__(cls,class_name,parents,class_attrs):
        new_attrs = [(k, v) for k, v in class_attrs.items() if not k.startswith("__") and not k.endswith("__")]
        upper_attrs = dict((k.upper(),v) for k,v in new_attrs)
        print(upper_attrs)
        return super(UpperAttrsMetaClass, cls).__new__(cls,class_name,parents,upper_attrs)


class Person(object,metaclass=UpperAttrsMetaClass):
    __metaclass__ = UpperAttrsMetaClass
    country = 'china'

print(Person.COUNTRY)
