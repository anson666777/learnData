#encoding: utf-8

class ZLList(object):
    def __init__(self,values=None):
        if values:
            self.values = values
        else:
            self.values = []

    def __len__(self):
        return len(self.values)

    def __getitem__(self, item):
        # 这种方式是为了跟大家介绍一下slice数据类型
        # if isinstance(item,slice):
        #     return self.values[item.start:item.stop:item.step]
        # else:
        #     return self.values[item]
        return self.values[item]

    def __setitem__(self, key, value):
        self.values[key] = value

    def __delitem__(self, key):
        del self.values[key]

    def __iter__(self):
        return iter(self.values)

    def __reversed__(self):
        return reversed(self.values)


my_list = ZLList(values=[1,2,3])
# 1. __len__测试：
# print(len(my_list))

# 2. __getitem__测试：slice
# print(my_list[0:2])

# 3. __setitem__测试：
# my_list[0] = 'a'
# print(my_list[0:2])

# 4. __delitem__测试：
# del my_list[0]
# print(my_list[0])

# 5. __iter__测试：
# for x in my_list:
#     print(x)

# 6. __reversed__测试：
for x in reversed(my_list):
    print(x)


