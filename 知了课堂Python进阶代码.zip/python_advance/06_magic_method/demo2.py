#encoding: utf-8

class Person(object):
    """
    判断两个对象大小的条件：
    1. 首先看age，谁的age大，谁就大
    2. 如果age相等，就看height，谁的height大，谁就更大
    """
    def __init__(self,name,age,height):
        self.name = name
        self.age = age
        self.height = height

    # __cmp__这个方法，只能在Python2中用
    # 在Python3中这个方法不再奏效了
    # def __cmp__(self,other):
    #     # self == other：返回0
    #     # self > other：返回正数，一般返回1
    #     # self < other：返回负数，一般返回-1
    #     if self.age == other.age:
    #         if self.height == other.height:
    #             return 0
    #         else:
    #             return 1 if self.height > other.height else -1
    #     else:
    #         return 1 if self.age > other.age else -1

    def __eq__(self, other):
        # if self.age == other.age and self.height == other.height:
        #     return True
        # else:
        #     return False
        return True if self.age==other.age and self.height==other.height else False

    def __ne__(self, other):
        if self.age != other.age or self.height != other.height:
            return True
        else:
            return False

    def __lt__(self, other):
        # 1. 如果self.age < other.age，那么说明self是小于other的
        # 这时候直接返回True就可以了
        # 2. 如果self.age == other.age，那么这时候还要比较self.height
        # 是否小于other.height
        print('lt_%s' % self.name)
        if self.age < other.age:
            return True
        else:
            if self.age == other.age:
                return True if self.height < other.height else False
            return False

    def __gt__(self, other):
        # 1. 判断如果self.age > other.age，那么直接返回True就可以
        # 2. 如果self.age==other.age，那么就判断height
        print('gt_%s' % self.name)
        if self.age > other.age:
            return True
        else:
            if self.age == other.age:
                return True if self.height > other.height else False
            else:
                return False

    def __le__(self, other):
        # 小于或者等于
        if self.__lt__(other) or self.__eq__(other):
            return True
        else:
            return False

    def __ge__(self, other):
        # 大于等于
        if self.__gt__(other) or self.__eq__(other):
            return True
        else:
            return False

p1 = Person('p1',20,180)
p2 = Person('p2',20,170)

if p1 <= p2:
    print(True)
else:
    print(False)