#encoding: utf-8

import pickle

def dump_built_in_obj():
    data = {'foo': [1, 2, 3],
           'bar': ('Hello', 'world!'),
           'baz': True}
    with open('build_obj.pkl','wb') as fp:
        pickle.dump(data,fp)

# dump_built_int_obj()

def load_built_in_obj():
    with open('build_obj.pkl','rb') as fp:
        t = pickle.load(fp)
        print(t)


class Cat(object):
    def __init__(self,name):
        self.name = name


class Person(object):
    def __init__(self,name,age):
        self.name = name
        self.age = age

    def __getstate__(self):
        # 这个方法中，只能返回能被Pickle存储的数据结构
        return {"name":self.name,'age':self.age}

    def __setstate__(self, state):
        print(state)
        self.name = state['name']
        self.age = state['age']

    def __str__(self):
        return "Person(name:%s,age:%d)" % (self.name,self.age)


def dump_obj():
    p1 = Person('zhiliao',18)
    with open('pickle_obj.pkl','wb') as fp:
        pickle.dump(p1,fp)

def load_obj():
    with open('pickle_obj.pkl','rb') as fp:
        t = pickle.load(fp)
        print(t)

load_obj()

