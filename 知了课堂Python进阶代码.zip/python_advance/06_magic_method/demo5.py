#encoding: utf-8

class Coordinate(object):
    def __init__(self,x,y):
        self.x = x
        self.y = y

    def __iadd__(self, other):
        x = self.x + other
        y = self.y + other
        return Coordinate(x,y)

    def __isub__(self, other):
        x = self.x - other
        y = self.y - other
        return Coordinate(x,y)

    def __imul__(self, other):
        x = self.x * other
        y = self.y * other
        return Coordinate(x,y)

    def __str__(self):
        return "(%s,%s)" % (self.x,self.y)

    def __itruediv__(self, other):
        x = self.x / other
        y = self.y / other
        return Coordinate(x,y)

c1 = Coordinate(1,2)
# c1 += 1
# c1 -= 1
# c1 *= 2
c1 /= 2
print(c1)