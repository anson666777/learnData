#encoding: utf-8

class Coordinate(object):
    def __init__(self,x,y):
        self.x = x
        self.y = y

    def __pos__(self):
        # positive
        return self

    def __neg__(self):
        # negative
        # self.x = -self.x
        # self.y = -self.y
        new_coordinate = Coordinate(-self.x,-self.y)
        return new_coordinate
        # self.x = -self.x
        # self.y = -self.y
        # return self

    def __abs__(self):
        new_coordinate = Coordinate(abs(self.x),abs(self.y))
        return new_coordinate

    def __invert__(self):
        new_coordinate = Coordinate(255-self.x,255-self.y)
        return new_coordinate

    def __str__(self):
        return "(%s,%s)" % (self.x,self.y)

c1 = Coordinate(-1,-2)
print(c1)
c2 = ~c1
print(c2)