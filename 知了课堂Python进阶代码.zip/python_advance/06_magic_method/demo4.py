#encoding: utf-8
from __future__ import division

class Coordinate(object):
    def __init__(self,x,y):
        self.x = x
        self.y = y

    def __add__(self, other):
        x = self.x + other.x
        y = self.y + other.y
        new_coordinate = Coordinate(x,y)
        return new_coordinate

    def __sub__(self, other):
        x = self.x - other.x
        y = self.y - other.y
        return Coordinate(x,y)

    def __mul__(self, other):
        x = self.x * other.x
        y = self.y * other.y
        return Coordinate(x,y)

    def __div__(self, other):
        x = self.x / other.x
        y = self.y / other.y
        return Coordinate(x,y)

    def __truediv__(self, other):
        x = self.x / other.x
        y = self.y / other.y
        return Coordinate(x, y)

    def __floordiv__(self, other):
        x = self.x // other.x
        y = self.y // other.y
        return Coordinate(x,y)

    def __mod__(self, other):
        x = self.x % other.x
        y = self.y % other.y
        return Coordinate(x,y)

    def __str__(self):
        return "(%s,%s)" % (self.x,self.y)

c1 = Coordinate(1,2)
c2 = Coordinate(2,3)
# c3 = c1+c2
# c3 = c1 - c2
# c3 = c1 * c2
# c3 = c2//c1
c3 = c1 % c2
print(c3)