#encoding: utf-8

class FileOpener(object):
    def __init__(self,filename,mode):
        self.filename = filename
        self.mode = mode

    def __enter__(self):
        self.fp = open(self.filename,self.mode)
        print('__enter__')
        return self.fp

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.fp.close()
        # print('__exit__')
        print(exc_type)
        print(exc_val)
        print(exc_tb)
        # 如果不想抛出异常，那么返回True，会自动的吸收这个异常
        return True


with FileOpener('abc.txt','w') as fp:
    fp.write('hello world')
    a = 1
    c = a/0



