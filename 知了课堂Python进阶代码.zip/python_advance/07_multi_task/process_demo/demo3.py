#encoding: utf-8

from multiprocessing import Process
import time
import os

class MyProcess(Process):
    def run(self):
        print('子进程的id：%s' % os.getpid())
        print('父进程的id：%s' % os.getppid())
        global ZHILIAO
        for x in range(5):
            ZHILIAO += 1
            print('子进程：%s' % x)

if __name__ == '__main__':
    p = MyProcess()
    p.start()

    print('父进程的id：%s' % os.getpid())
    print('子进程开始了')
    p.join()
    print('子进程执行完毕')