#encoding: utf-8

import os
import time
from multiprocessing import Pool

def copy_file(old_path,new_path):
    with open(old_path, 'rb') as fp_r:
        with open(new_path, 'wb') as fp_w:
            for x in fp_r:
                fp_w.write(x)
        print('%s 复制完成！' % os.path.split(old_path)[-1])


if __name__ == '__main__':
    old_path = os.path.join(os.getcwd(), 'videos')
    new_path = os.path.join(os.getcwd(), 'videos_copy')
    videos = os.listdir(old_path)

    pool = Pool(4)

    start_time = time.time()
    for video in videos:
        video_path = os.path.join(old_path, video)
        cp_video_path = os.path.join(new_path, video)
        pool.apply_async(copy_file, args=(video_path,cp_video_path))
        # copy_file(video_path,cp_video_path)

    pool.close()

    pool.join()
    end_time = time.time()
    print('总共耗时：%s' % (end_time-start_time))