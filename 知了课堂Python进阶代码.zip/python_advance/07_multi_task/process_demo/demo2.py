#encoding: utf-8

from multiprocessing import Process
import time

def zhiliao():
    for x in range(5):
        print('子进程：%s' % x)
        time.sleep(1)

if __name__ == '__main__':
    p = Process(target=zhiliao)
    p.start()

    print('主进程')

    # join方法的时候，就相当于主进程会阻塞在这个地方
    # 直到这个子进程执行完毕以后才会执行父进程后的代码
    p.join(3)
    print('所有子进程都执行完毕')