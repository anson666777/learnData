#encoding: utf-8

from multiprocessing import Process,Queue,Pool,Manager
import os

def write(q):
    for x in ['m1','m2','m3']:
        q.put(x)
        print('子进程%s已经存放了消息：%s' % (os.getpid(),x))

def read(q):
    while True:
        try:
            msg = q.get(block=False)
            print('子进程%s已经读取了消息：%s' % (os.getpid(),msg))
        except:
            print('所有消息都已经取出来了')
            break

if __name__ == '__main__':
    q = Manager().Queue()
    pool = Pool(2)
    pool.apply(func=write,args=(q,))
    pool.apply(func=read,args=(q,))

    pool.close()

    pool.join()
