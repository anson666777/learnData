#encoding: utf-8

from multiprocessing import Queue

# Queue可以指定maxsize的值
# 以后这个队列中就只能装maxsize个值
# 如果不指定，那么就是为-1
# -1 意味着可以装任意多个消息，指导你的内存满了
q = Queue(3)

# put方法：可以传递任意数据类型的消息
q.put(['1','2'])
q.put('m2')
q.put('m3')
# qsize：获取这个消息队列中总共的消息数量
print('qsize:%s' % q.qsize())
# full：如果消息队列满了，那么会返回True，否则返回False
print(q.full())
# empty：如果消息队列为空，那么会返回True，否则返回False
print(q.empty())

# put方法默认是阻塞的方式
# 如果消息队列已经满了，那么会阻塞在这个地方，指导这个消息队列没有满为止
# block参数：可以设置为False，如果为False，那么意味着不会阻塞，如果
# 消息队列满了，那么会立马抛出一个异常
# timeout参数：指定阻塞的最长时间。如果超过了这个时间就不再阻塞，而是抛出一个异常。
# q.put('m4',block=True,timeout=2)
# put_nowait：其实等价于q.put(obj,block=False)
# q.put_nowait('m4')
# print('finished')

# get方法：获取到的是第一个添加进去的值。
# get方法：除了获取这个值外，还会把这个值从消息队列中删除掉
# block参数：默认是等于True，即以阻塞的方式获取值，如果这个队列中没有任何消息，
# 那么会阻塞到这个地方。如果block=False，那么如果队列中没有值，就会立即抛出异常。
# timeout参数：指定阻塞的最长事件。如果超过了这个时间就不再阻塞，而是抛出一个异常
print(q.get())
print(q.get())
print(q.get())
print(q.get(block=True,timeout=2))