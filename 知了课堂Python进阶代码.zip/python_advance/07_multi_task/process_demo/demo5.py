#encoding: utf-8

from multiprocessing import Process

AGE = 1

def hello():
    print('hello')

def greet(names):
    global AGE
    AGE += 1
    names.append('ketang')
    print('=====子进程代码=====')
    print('AGE的值：%d，AGE的id：%s' % (AGE,id(AGE)))
    print('names：%s' % names)
    print(id(hello))
    print('=====子进程代码=====')


if __name__ == '__main__':
    names = ['zhiliao']
    p = Process(target=greet,args=(names,))
    p.start()
    p.join()
    print('=====父进程代码=====')
    print('AGE的值：%d，AGE的id：%s' % (AGE, id(AGE)))
    print('names：%s' % names)
    print(id(hello))
    print('=====父进程代码=====')