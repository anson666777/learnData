#encoding: utf-8

from multiprocessing import Pool
import os
import time

def zhiliao(num):
    for x in range(5):
        print('子进程id：%s,值：%s' % (os.getpid(),num))
        time.sleep(2)


if __name__ == '__main__':
    pool = Pool(4)
    for x in range(10):
        pool.apply(zhiliao,args=(x,))

    pool.close()
    pool.join()