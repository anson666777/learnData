#encoding: utf-8

import os
import time
from multiprocessing import Pool

# 1. os.getcwd：获取当前执行文件的路径
# 2. os.path.join：拼接两个路径。可以跨平台
# 3. os.listdir(path)：获取path路径下所有的文件
# 4. os.path.split：可以分割路径与文件名


def copy_file(old_path,new_path):
    with open(old_path, 'rb') as fp_r:
        with open(new_path, 'wb') as fp_w:
            for x in fp_r:
                fp_w.write(x)
    print('%s 文件拷贝完成!' % os.path.split(old_path)[-1])


def main():
    video_path = os.path.join(os.getcwd(), 'videos')
    video_path_copy = os.path.join(os.getcwd(), 'videos_copy')

    videos = os.listdir(video_path)

    pool = Pool(2)

    # 单进程的方式：总共耗费51.24333643913269秒
    # 多进程的方式：

    start_time = time.time()
    for video_name in videos:
        old_path = os.path.join(video_path, video_name)
        new_path = os.path.join(video_path_copy, video_name)
        # copy_file(old_path,new_path)
        pool.apply_async(copy_file,args=(old_path,new_path))

    pool.close()
    pool.join()
    end_time = time.time()
    print('总共耗费%s秒' % (end_time-start_time))

if __name__ == '__main__':
    main()
    # print(os.path.split(__file__))
