#coding: utf-8

from multiprocessing import Process
import time
import os

def zhiliao():
    print('===子进程开始===')
    print('子进程id：%s' % os.getpid())
    print('父进程id：%s' % os.getppid())
    print('===子进程结束===')

if __name__ == '__main__':
    p = Process(target=zhiliao)
    p.start()
    print('父进程id：%s' % os.getpid())
    print('我是主进程的代码')