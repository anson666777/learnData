#coding: utf-8


# id,type,name,price
class Pet(object):
	def __init__(self,pet_id,pet_name,pet_type,pet_price):
		self.id = pet_id
		self.pet_name = pet_name
		self.pet_type = pet_type
		self.pet_price = pet_price

	def get_line(self):
		id = self.id
		name = self.name
		type = self.type
		price = self.price
		line = "{id}&{name}&{type}&{price}\n".format(id,name,type,price)
		return line

	@classmethod
	def get_pet(cls,line):
		infos = line.split("&")
		id = infos[0]
		name = infos[1]
		type = infos[2]
		price = infos[3]
		return Pet(pet_id=id,pet_name=name,pet_type=type,pet_price=price)

class PetManager(object):
	__instance = None
	__filename = 'pet_book.txt'

	def __new__(cls,*args,**kwargs):
		print(args)
		if not cls.__instance:
			cls.__instance = super(PetManager,cls).__new__(cls)
		return cls.__instance

	def __init__(self):
		super(PetManager,self).__init__()
		

	def add_pet(self,pet):
		with open(PetManager.__filename,'a') as fp:
			line = pet.get_line()
			fp.write(line)

	def delete_pet(self,pet_id):
		pets = []
		with open(PetManager.__filename,'r') as fp:
			for line in fp:
				pet = Pet.get_pet(line)
				if pet.pet_id != pet_id:
					pets.append(pet)

		with open(PetManager.__filename,'w') as fp:
			for pet in pets:
				line = pet.get_line()
				fp.write(line)


class Application(object):
	__instance = None
	def __new__(cls,*args,**kwargs):
		if not cls.__instance:
			cls.__instance = super(Application,cls).__new__(cls)
		return cls.__instance

	def input_pet_info(self):
		global pet_manager
		print('=========')
		print(pet_manager)
		print(NAME)
		print('=========')
		id = input('请输入宠物的id：')
		name = input('请输入宠物的名字：')
		type = input('请输入宠物的类型：')
		price = input('请输入宠物的价格：')
		pet = Pet(id,name,type,price)
		pet_manager.add_pet(pet)
		print('恭喜！宠物寄养成功！')

	def list_all_info(self):
		pass

	def run(self):
		print('0. 退出系统')
		print('1. 添加宠物')
		print('2. 列出所有宠物')
		while True:
			option = input('请输入选项：')
			if option == '0':
				break
			elif option == '1':
				self.input_pet_info()
			elif option == '2':
				self.list_all_info()

pet_manager = PetManager()
app = Application()
app.run()