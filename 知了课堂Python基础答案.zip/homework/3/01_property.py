#coding: utf-8

# property：可以将一个方法变成一个属性

class Rectangle(object):

	def __init__(self,width,height):
		self._width = width
		self._height = height
		# 周长
		self.length = 2*width + 2*height

	@property
	def width(self):
		return self._width

	@width.setter
	def width(self,value):
		self._width = value
		self.length = self._width*2 + self._height*2


rect = Rectangle(2,3)
print(rect.length)
rect.width = 10
print(rect.length)

# rect.length = rect.width*2 + rect.height*2
