#coding: utf-8

# 1. 什么是面向对象

# 2. 新式类和旧式类
# 2.1 新式类是在定义类的时候祖先类是object就是新式类。
# 2.2 旧式类在定义类的时候祖先类不是object就是旧式类。
# class Person(object):
# 	pass
# # property
# class Student(Person):
# 	pass

# 3. 私有属性和受保护的属性
# 3.1 私有属性：是以__开头的属性就是私有属性。比如__age
# class Person(object):
# 	def __init__(self,age):
# 		self.__age = age
# 		# self._Person__age = age

# p = Person(20)
# print(p._Person__age)

# 3.2 受保护的属性：开发者在定义这个属性的时候，其实是不想让外界访问的，但是如果你确实是要
# 访问，那也可以
# 私有属性使用的是一个下划线，比如_age
# class Person(object):
# 	def __init__(self,age):
# 		self._age = age

# p = Person(20)
# print(p._age)


# 4. 继承和多继承
# class Person(object):
# 	def __init__(self, name,age):
# 		super(Person, self).__init__()
# 		self.name = name
# 		self.age = age

# class Student(Person):
# 	def __init__(self,name,age,class_room):
# 		super(Student,self).__init__(name,age)
# 		self.class_room = class_room

# s = Student('zhiliao',18,'1111')
# print(s.name)
# print(s.age)
# print(s.class_room)

# class Animal(object):
# 	def __init__(self,weight):
# 		self.weight = weight

# 	def eat(self):
# 		pass

# class Ma(Animal):
# 	def __init__(self,weight):
# 		super(Ma,self).__init__(weight)

# 	def eat(self):
# 		print('马在吃草')

# 	def run(self):
# 		print('马在奔跑')

# class Lv(Animal):
# 	def __init__(self,weight):
# 		super(Lv,self).__init__(weight)

# 	def eat(self):
# 		print('驴在吃小麦')

# 	def lamo(self):
# 		print('驴在拉磨')

# class Luozi(Ma,Lv):
# 	def __init__(self,weight):
# 		# super(Luozi,self).__init__(weight)
# 		Lv.eat(self)

# luozi = Luozi(300)
# # C3算法：广度优先
# # luozi.run()
# print(Luozi.__mro__)
# luozi.eat()

# class Person(object):
# 	def __init__(self,name):
# 		self.name = name

# class Student(Person):
# 	def __init__(self,name,age):
# 		# super(Student,self).__init__(name)
# 		# ！！！在旧式类中，如果要调用父类的方法，只能通过`类名.方法名`来调用
# 		# 以后如果你在调用父类的时候，
# 		# 出现了TypeError: super() argument 1 must be type, not classobj
# 		# 说明父类是一个旧式类
# 		# 在调用父类的时候，如果父类需要什么参数就要传什么参数
# 		# Person.__init__(self,name)
# 		# super就是用来去__mro__列表中查找正确的父类
# 		super(Student,self).__init__(name)
# 		print(id(self))

# s = Student('zhiliao',18)
# # s2 = Student('zhiliao',20)
# # 元类：类也是一种对象

# # 5. 多态
# class Hero(object):
# 	def __init__(self,name,move_speed,play_speed):
# 		self.name = name
# 		self.move_speed = move_speed
# 		self.play_speed = play_speed

# 	def one_skill(self):
# 		pass

# 	def two_skill(self):
# 		pass

# 	def three_skill(self):
# 		pass

# class Luban(Hero):
# 	def __init__(self,name,move_speed,play_speed):
# 		super(Luban,self).__init__(name,move_speed,play_speed)

# 	def one_skill(self):
# 		print('仍炸弹')

# 	def two_skill(self):
# 		print('发射大炮')

# 	def three_skill(self):
# 		print('发出一个大圆圈')

# class Chengyaojin(Hero):
# 	def __init__(self,name,move_speed,play_speed):
# 		super(Luban,self).__init__(name,move_speed,play_speed)

# 	def one_skill(self):
# 		print('跳出一个程咬金')

# 	def two_skill(self):
# 		print("旋转")

# 	def three_skill(self):
# 		print('回血加攻击力')

# hero_index = input('请输入英雄：')
# hero = None
# if hero_index == '1':
# 	hero = Luban('鲁班',2,4)
# elif hero_index == '2':
# 	hero = Chengyaojin('程咬金',2,5)


# def play_skill(hero,skill):
# 	skill = input('请输入要输出的技能：')
# 	if skill == '1':
# 		# 5v5
# 		hero.one_skill()
# 	elif skill == '2':
# 		hero.two_skill()
# 	else:
# 		hero.three_skill()

# 鸭子类型


# 6. 实例属性和类属性
# 绑定到对象上的属性就叫做实例属性
# 绑定到类对象上的属性就叫做类属性
# class Person(object):
# 	country = 'china'
# 	def __init__(self,name):
# 		self.name = name

# # print(Person.country)
# # 可以通过对象的方式访问类属性
# p = Person('zhiliao')
# print(p.country)
# # Person.country = 'zhiliao'
# p.country = 'zhiliao'
# print(p.country)
# print(Person.country)
# print(Person.name)
# p = Person('zhiliao')
# p.name = 'zhiliao'
# print(p.name)

# p1 = Person('ketang')
# print(p1.name)


# 7. 类方法和静态方法
# class Person(object):
# 	country = 'china'
# 	def __init__(self,name):
# 		self.name = name
# 	# 如果要定义一个类方法，需要加一个装饰器classmethod
# 	# 装饰器如何使用：使用@+装饰器名字，放在需要装饰的函数上一行
# 	@classmethod
# 	def run(cls): # cls == class
# 		print(Person.country)
# 		print(cls.country)
# 		print('run')

# 	# 静态方法：使用staticmethod装饰器
# 	# 静态方法使用场景：一般是和这个类逻辑没有什么关系，但是把这个方法放到这个类中
# 	# 能够让你的代码更加有组织性，更加模块化，那么就可以把这个方法定义成类方法
# 	@staticmethod
# 	def go():
# 		print('go')

# p = Person('name')
# p.go()
# 如果不需要访问实例对象的属性，那么可以使用类方法
# 因为类方法调用的时候更加方便，不需要先初始化一个对象
# Person.go()


# 8. __new__方法和__init__方法
# 在其他编程语言中，构造方法做了两件事情：
# 1. 第一个是在内存中创建一个对象
# 2. 第二个是将创建出来的对象进行初始化
# 旧式类中没有__new__方法
# class Person:
# 	# new方法类方法，所以要传cls
# 	# 类方法继承，需要传cls参数
# 	def __new__(cls,*args,**kwargs):
# 		print('new method')
# 		# 如果自己重写了new方法，那么必须要返回父类new方法的值
# 		return super(Person,cls).__new__(cls,*args,**kwargs)


# 	def __init__(self):
# 		print('init method')
# 		self.name = 'zhiliao'


# p = Person()

# 9. 单例设计模式：就是一个类在整个程序运行期间，只有一个对象
# pygame
class Person(object):
	
	__instance = None
	flag = 0

	def __new__(cls,*args,**kwargs):
		print('new method')
		cls.flag += 1
		if not cls.__instance:
			cls.__instance = super(Person,cls).__new__(cls,*args,**kwargs)

		# 如果new方法中返回了对象，就会调用init方法
		return cls.__instance
		

	def __init__(self):
		print('init method')

p = Person()
p2 = Person()
print(id(p))
print(id(p2))

# 10. 宠物寄养管理系统——面向对象版
# 宠物
# 管理系统
# 文件操作

# 998
