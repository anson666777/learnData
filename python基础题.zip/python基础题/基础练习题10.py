# 定义一个函数，求 1-100 直接所有整数的和，并打印结果
def sum():
    s = 0
    for i in range(1, 101):
        s += i
    print(s)

sum()
