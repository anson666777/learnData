# 编写程序，把 1-100 倒序打印出来。(for 循环,rang 生成 1-100)

for i in [i+1 for i in range(0, 100)][::-1]:
    print(i)



