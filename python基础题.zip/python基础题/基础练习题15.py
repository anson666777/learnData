# 编写一个函数模拟登录，当用户名 name=’zhiliao’,密码 password=’123456’，
# 输出登陆成功， 否则登陆失败，允许失败登陆 3 次。


def login():
    i = 0
    while i <= 3:
        name = input('请输入用户名:')
        password = input('请输入密码:')
        if name == 'zhiliao' and password == '123456':
            print('登录成功!!!')
            break
        print('登录失败!!!')
        i += 1
    print('不允许在登录!')

login()