#  计算 1-100 所有的奇数和，所有偶数和
sum_q = 0
sum_n = 0
for i in range(1, 101):
    if i % 2 == 0:
        sum_n += i
    else:
        sum_q += i

print('奇数和{}'.format(sum_q))
print('偶数和{}'.format(sum_n))
