L1 = [1, 3, 2, 'a', 4, 'b', 5, 'c', 6]
l2 = L1[3:-1]

del l2[1]
del l2[2]
print(l2)