#  编写一个程序，统计该字符串中 s='you can hear the whistle blow a hundred miles' 各个字符 的个数。
# (y:1 o:2 u:2 c:1 a:3 n:2 h:4 e:5 r:2 t:2 w:2 i:2 s:2 l:3 b:1 d:2 m:1)
dicts = {}
strs = 'youcanhearthewhistleblowahundredmiles'
for s in strs:
    if s not in dicts.keys():
        dicts[s] = 1
    else:
        dicts[s] = dicts[s] + 1
print(dicts)