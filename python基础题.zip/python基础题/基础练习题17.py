"""
 给定一个字典 dict={'k1':'v1','k2':'v2','k3':[1,2,3]},
1) 依次输出所有的键，
2) 依次输入所有 的值，
3) 添加 k4;v4 键值对，
4) 在 K3 末尾增加元素 4,
5) 在 k3 第一位置插入 0
"""
dict = {'k1': 'v1', 'k2': 'v2', 'k3': [1, 2, 3]}

# 1.
for key in dict.keys():
    print(key)

# 2.
for value in dict.values():
    print(value)

# 3.
dict['k4'] = 'v4'
print(dict)

# 4.
dict['k3'].append(4)
print(dict)

# 5.
dict['k3'].insert(0, 0)
print(dict)
