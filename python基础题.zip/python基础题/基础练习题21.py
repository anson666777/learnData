"""给定一个变量 action="let's go",
1).判断变量是否以 ’g’ 开头，是否以 ’o’ 结尾,
2) 将’go’ 替换成’move’ """

action = "let's go"
if action.startswith('g'):
    print('%s以g开头' % action)
else:
    print('%s不以g开头' % action)

if action.endswith('o'):
    print('%s以o' % action)
else:
    print('%s不以o开头' % action)

# print(action.replace(action, "let's movie"))
print(action.replace('go', "movie"))

