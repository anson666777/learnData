# 给定一个字符串 s=’zhiliao’，按如下要求进行转换：
# 1) 将字符串转换成列表， 2) 将字符串转换成元组。

s = 'zhiliao'
print(list(s))
print(tuple(s))