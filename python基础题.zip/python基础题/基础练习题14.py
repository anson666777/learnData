# 写一个程序输出 9*9 乘法口诀表（循环嵌套）

for j in range(1,10):
    for k in range(1, j+1):
        print('{}x{}={}\t'.format(k, j, j*k), end='')
    print()






