# 给定一个字符串 s='hello python', 将字符串倒序输出

s = 'hello python'
print(s[::-1])
