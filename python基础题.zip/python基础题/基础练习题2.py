# 请定义一个变量 str1 并赋值一个字符串"hello"，
# 再定义一个变量 str2 并赋值一个字符串"python"，
# 那么 str1 + str2 的值是多少？

str1 = 'hello'
str2 = 'python'
print(str1 + str2)


