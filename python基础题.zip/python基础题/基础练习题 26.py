"""
 编写一个程序，当 学习成绩 grade>=90 分的同学用 A 表示，60-89 分之间的同学用 B 表示，
 60 分一下用 C 表示，分数从键盘获取（分数 0-100，判断是否合法输入，不是合法输入并提示）。
"""


while True:
    grade = int(input('请输入分数:'))
    if grade > 100 or grade < 0:
        print('请合法输入!')
        continue
    else:
        if grade >= 90:
            print('A')
            break
        elif 60 <= grade < 90:
            print('B')
            break
        else:
            print('C')
            break
