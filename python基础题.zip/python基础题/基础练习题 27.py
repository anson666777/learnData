"""
 任意输入一行字符串(非空)，单词以空格隔开，输出最后一个字符串，以及最后一个字符串的长度。
 列如（输入’world’, 输出world, 字符长度 5. 输入’hello world’,输出 world,字符长度 5）。
"""

s = 'tomorrow is nice day'
ls = s.split(' ')
# print(ls[-1])
if len(ls) == 1:
    print(ls[0])
    print(len(s))
else:
    print(ls[-1])
    print(len(ls[-1]))




