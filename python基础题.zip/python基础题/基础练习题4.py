#  编写代码 1-7 七个数字，分别代表周一到周日，如果输入的数字是 6 或 7，输出“周末”。
day = int(input('请输入数字:'))
if day == 6 or day == 7:
    print('周末')
else:
    print('输入错误')