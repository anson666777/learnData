# 使用字典来存储一个人的信息（姓名、年龄、学号、QQ、微信、住址等），这些信息来自 键盘的 输入（input）。

name = input('姓名：')
age = input('年纪：')
study_num = input('学号:')
QQ = input('QQ：')
weixin = input('微信：')
address = input('地址：')

person = {
    'name': name,
    'age ': age,
    'study_num': study_num,
    'QQ': QQ,
    'weixin': weixin,
    'address': address,
}
