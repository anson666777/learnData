#  a = 1, b = 2, 则(a == b) 、(a != b) 、
# (a > b) 、(a < b) 、(a >= b) 、(a <= b) 分别返回什么?

# False
# True
# False
# True
# False
# True
# True
