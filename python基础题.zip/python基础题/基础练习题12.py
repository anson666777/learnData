# 定义一个函数求前 20 个斐波那契数列。（斐波那契数列：1,1,2,3,5,8,13,21.......前两项为 1， 后面的项均为前两项和）


def feibo(j):
    a = 1
    b = 1
    i = 1
    while i <= j:
        print(a)
        a, b = b, a + b
        i += 1
    return a


sum = feibo(20)
