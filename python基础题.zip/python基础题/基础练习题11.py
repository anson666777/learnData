# 定义一个函数，判断任意输入的年份是否是闰年。（闰年：能被 400 整除 或 能被 4 整除， 但不能被 100 整除）
while True:
    year = int(input('请输入年份:'))
    if year % 400 == 0:
        print('{}是闰年'.format(year))
        break
    elif (year % 4 == 0 and year % 100 != 0):
        print('{}是闰年'.format(year))
        break
    print('请重新输入年份')
    print('-'*50)