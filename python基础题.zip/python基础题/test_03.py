# s = 'hello'
s = 'tomorrow is nice day'
ls = s.split(' ')
# print(ls[-1])
if len(ls) == 1:
    print(ls[0])
    print(len(s))
else:
    print(ls[-1])
    print(len(ls[-1]))
