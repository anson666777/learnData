# 输入三个整数，x,y,z 请把这三个数由小到大输出
x = int(input('请输入整数：'))
y = int(input('请输入整数：'))
z = int(input('请输入整数：'))

ilist = [x, y ,z]
ilist.sort()
for i in ilist:
    print(i)

