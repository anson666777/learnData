import xlwt
import random


workbook = xlwt.Workbook(encoding='utf-8')
sheet = workbook.add_sheet("成绩表")

sheet.write(0,0,"语文")
sheet.write(0,1,"数学")
sheet.write(0,2,"英语")

for row in range(1,11):
    for col in range(0,3):
        sheet.write(row,col,random.randint(40,100))

workbook.save("scores.xls")