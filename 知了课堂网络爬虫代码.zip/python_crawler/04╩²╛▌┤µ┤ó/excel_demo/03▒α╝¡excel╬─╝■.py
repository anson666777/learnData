import xlrd
import xlwt

rwb = xlrd.open_workbook("成绩表.xlsx")
rsheet = rwb.sheet_by_index(0)

# 添加总分的cell
rsheet.put_cell(0,4,xlrd.XL_CELL_TEXT,"总分",None)

# 添加总分的数据
nrows = rsheet.nrows
ncols = rsheet.ncols
for row in range(1,nrows):
    scores = rsheet.row_values(row,1,4)
    rsheet.put_cell(row,4,xlrd.XL_CELL_NUMBER,sum(scores),None)

# 添加每个科目的平均分
for col in range(1,rsheet.ncols):
    scores = rsheet.col_values(col,1,nrows)
    avg = sum(scores)/len(scores)
    rsheet.put_cell(nrows,col,xlrd.XL_CELL_NUMBER,avg,None)


# 编辑的实质：读取->编辑->写入一个新的excel文件
wwb = xlwt.Workbook(encoding='utf-8')
wsheet = wwb.add_sheet("xxx")
for row in range(rsheet.nrows):
    for col in range(rsheet.ncols):
        value = rsheet.cell_value(row,col)
        wsheet.write(row,col,value)
wwb.save("新成绩表.xls")