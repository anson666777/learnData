import xlrd

workbook = xlrd.open_workbook("成绩表.xlsx")

####################sheet相关的操作####################
#sheets = workbook.sheet_names()
# print(sheets)

# for index in range(3):
#     sheet = workbook.sheet_by_index(index)
#     print(type(sheet))
#     print(sheet.name)

# sheet = workbook.sheet_by_name("1班")
# print(sheet.name)

# for sheet in workbook.sheets():
#     print(sheet.name)

# sheet0  =workbook.sheet_by_index(0)
# print("行数：%d"%sheet0.nrows)
# print("列数：%d"%sheet0.ncols)
####################sheet相关的操作####################


####################Cell相关的操作####################
sheet = workbook.sheet_by_index(0)

# cell = sheet.cell(0,0)
# print(type(cell))
# print(cell)

# cells = sheet.row_slice(1,1,4)
# total = sum([cell.value for cell in cells])
# print(total)

# cells = sheet.col_slice(1,1,sheet.nrows)
# avg = sum([cell.value for cell in cells])/len(cells)
# print(avg)

# scores = sheet.col_values(1,1,sheet.nrows)
# avg = sum(scores)/len(scores)
# print(avg)
####################Cell相关的操作####################



####################Cell的数据类型####################
sheet = workbook.sheet_by_index(0)
# cell = sheet.cell(0,0)
# print(cell.ctype)
# print(xlrd.XL_CELL_TEXT)

# cell = sheet.cell(1,1)
# print(cell.ctype)
# print(xlrd.XL_CELL_NUMBER)

# cell = sheet.cell(19,0)
# print(cell.ctype)
# print(xlrd.XL_CELL_DATE)

# cell = sheet.cell(19,1)
# print(cell.ctype)
# print(xlrd.XL_CELL_BOOLEAN)

cell = sheet.cell(19,2)
print(cell.ctype)
print(xlrd.XL_CELL_EMPTY)
####################Cell的数据类型####################