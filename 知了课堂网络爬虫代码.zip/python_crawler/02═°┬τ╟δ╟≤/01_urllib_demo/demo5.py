#encoding: utf-8

# 大鹏董成鹏主页：http://www.renren.com/880151247/profile
# 人人网登录url：http://www.renren.com/PLogin.do

from urllib import request
from bs4 import BeautifulSoup


# 1. 不使用cookie去请求大鹏的主页
dapeng_url = "http://www.renren.com/880151247/profile"
headers = {
    'User-Agent':"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
    "Cookie":"anonymid=kap66f4n-zh275f; depovince=HUN; _r01_=1; taihe_bi_sdk_uid=353b709c89683f05ff7d5fb00694da86; taihe_bi_sdk_session=2f3abe1a3c3c6b3130110b5ed83cccab; ick_login=6ef565fe-f774-4d11-bc62-0c6e35873142; _de=EA5778F44555C091303554EBBEB4676C696BF75400CE19CC; ick=6b2522b0-cb97-4eca-a6ff-14baee2a9704; __utma=151146938.856229357.1590573868.1590573868.1590573868.1; __utmc=151146938; __utmz=151146938.1590573868.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); __utmt=1; __utmb=151146938.4.10.1590573868; jebecookies=28aa5514-df1a-45b8-b794-ce9069a9e7e9|||||; JSESSIONID=abct_gZ-uI_ileMPwMvjx; p=88a1d7c2375a7d3f714eb3b3f4c2821c1; first_login_flag=1; ln_uact=970138074@qq.com; ln_hurl=http://hdn.xnimg.cn/photos/hdn121/20170428/1700/main_nhiB_aebd0000854a1986.jpg; t=c5a0c351da136cfef9122c2fe8ef00471; societyguester=c5a0c351da136cfef9122c2fe8ef00471; id=443362311; xnsid=aa660afd; ver=7.0; loginfrom=null; jebe_key=e76d4926-c4a6-41f5-b55c-05052736f4ff%7Ca022c303305d1b2ab6b5089643e4b5de%7C1590574055665%7C1%7C1590574057768; jebe_key=e76d4926-c4a6-41f5-b55c-05052736f4ff%7Ca022c303305d1b2ab6b5089643e4b5de%7C1590574055665%7C1%7C1590574057769; wp_fold=0"
}
req = request.Request(url=dapeng_url,headers=headers)
resp = request.urlopen(req)
with open('renren.html','w',encoding='utf-8') as fp:
    # write函数必须写入一个str的数据类型
    # resp.read()读出来的是一个bytes数据类型
    # bytes -> decode -> str
    # str -> encode -> bytes
    fp.write(resp.read().decode('utf-8'))