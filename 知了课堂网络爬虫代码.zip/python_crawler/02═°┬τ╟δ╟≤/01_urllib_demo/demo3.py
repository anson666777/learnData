#encoding: utf-8

from urllib import request,parse


url = "https://music.163.com/weapi/cloudsearch/get/web?csrf_token="
headers = {
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36"
}
formdata = {
    "params": "foUlX36kSAGPWtUp5SoqQTK9qDpJUuld45H57CYE49VM4zPJq8qwZxFwvL5djdWf61EFKPmFBZEzQ0wajuz1dE8a/pPKLciXET2mpGG3Pq1cWCMkOL1/kOSre2Qu0dHojZjHbHii/RbSNtmdIwVKbRD660wt8FBRRamrKbryU9NriJv5bLagmaFQ7aaOh5QQ6fjS2ENsAViwTVU58yvD85TWjS6zop28bhbLGePML4x3n8qaYIlAza4UNKaTAJ3wZNn7AdVP2FGbzD8NiSYjW/Wc+UwgsqWjsUU5wzmFf/Q=",
    "encSecKey": "32c74c08ae72ff1e5c39de0fb64b15b981d50f873a0afb73c4511939d67bc83fd101ed53f347798a10a86fb46cb55f651c1256413de44cd9ecc197c5cbd3eda58aa4075aeb2ca73b0fe4c6b23248200dc85b23f3206ab06e6e4568aa02219396b8203f886dc3fa08c2a7e2ff283eabf60e992bc10f7bafb9ab89ab8dd3b3a020"
}

# str => bytes：encode
# bytes => str：decode
# Request：默认情况下是get请求，但是只要传了data参数，就是post请求了。
req = request.Request(url=url,headers=headers,data=parse.urlencode(formdata).encode("utf-8"),method="POST")
resp = request.urlopen(req)
print(resp.read().decode("utf-8"))