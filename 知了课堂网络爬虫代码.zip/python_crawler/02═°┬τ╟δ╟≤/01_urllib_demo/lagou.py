"""
@author：hynev
@datetime：2019/7/15 10:15
"""
#encoding: utf-8

from urllib import request,parse

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0",
    "Referer": "https://www.lagou.com/jobs/list_java?labelWords=&fromSearch=true&suginput=",
    "Origin": "https://www.lagou.com",
    "Host": "www.lagou.com",
}

data = {
    "first": "true",
    "pn": 1,
    "kd": "java"
}

url1 = "https://www.lagou.com/jobs/list_java?labelWords=&fromSearch=true&suginput="
url2 = "https://www.lagou.com/jobs/positionAjax.json?needAddtionalResult=false"

import requests
session = requests.Session()
session.get(url1,headers=headers)
resp = session.post(url2,headers=headers,data=data)
print(resp.json())

# req = request.Request("https://www.lagou.com/jobs/positionAjax.json?needAddtionalResult=false",data=parse.urlencode(data).encode("utf-8"),headers=headers,method='POST')
# resp = request.urlopen(req)
# print(resp.read().decode("utf-8"))