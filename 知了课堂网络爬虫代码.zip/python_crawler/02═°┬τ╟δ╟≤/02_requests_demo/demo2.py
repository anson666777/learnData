#encoding: utf-8

import requests

# 1. 我们使用requests.post方法就可以发送post请求了
# 2. form表单，通过requests.post中的data来指定的

url = "https://httpbin.org/post"
formdata = {
    "username": "zhiliao ketang",
    "password": "111111"
}

resp = requests.post(url,data=formdata)
print(resp.text)