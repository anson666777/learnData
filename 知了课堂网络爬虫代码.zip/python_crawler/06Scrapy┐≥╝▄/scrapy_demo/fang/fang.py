from lxml import etree

fp = open("fang.html",'r',encoding='utf-8')

parser = etree.HTML(fp.read())

dls = parser.xpath("//div[contains(@class,'shop_list')]/dl")

for dl in dls:
    # name = dl.xpath(".//span[@class='tit_shop']/text()")[0].strip()
    infos = dl.xpath(".//p[@class='tel_shop']/text()")
    rooms = infos[0].strip()
    area = infos[1].strip()
    floor = infos[2].strip()
    toward = infos[3].strip()
    print('%s,%s,%s.%s'%(rooms,area,floor,toward))
