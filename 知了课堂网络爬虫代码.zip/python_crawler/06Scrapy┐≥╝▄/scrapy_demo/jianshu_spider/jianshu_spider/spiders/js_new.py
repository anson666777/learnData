# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from jianshu_spider.items import ArticleItem


class JsSpider(CrawlSpider):
    name = 'js_new'
    allowed_domains = ['jianshu.com']
    start_urls = ['https://www.jianshu.com/']

    rules = (
        Rule(LinkExtractor(allow=r'.*/p/[0-9a-z]{12}.*'), callback='parse_detail', follow=True),
    )

    def parse_detail(self, response):
        # ['蜕变挣脱', '关注', '89', '2020.05.04 05:03:33', '字数 614', '阅读 27,891', '性玩具', '阅读 33,539']
        title = response.xpath("//section[position()=1]/h1/text()").get()
        article_infos = response.xpath("//section[position()=1]/div[position()=1]//text()").getall()
        author = article_infos[0]
        pub_time = article_infos[3]
        read_count = article_infos[5].replace("阅读","").strip()
        word_count = article_infos[4].replace("字数","").strip()

        subjects = ",".join(response.xpath("//section[position()=3]/div[position()=1]//text()").getall()[:-1])
        interact_infos = response.xpath("//footer/div/div/div[position()=2]/div/span/text()").getall()
        # ['评论', '134', '赞', '484']
        comment_count = interact_infos[1]
        like_count = interact_infos[3]
        article_id = response.url.replace("https://www.jianshu.com/p/","")
        content = "".join(response.xpath("//section[position()=1]/article//text()").getall())
        avatar = response.xpath("//section[position()=1]//img/@src").get()


        item = ArticleItem(
            title=title,
            avatar=avatar,
            author = author,
            pub_time = pub_time,
            origin_url = response.url,
            article_id = article_id,
            content = content,
            subjects = subjects,
            word_count = word_count,
            comment_count = comment_count,
            read_count = read_count,
            like_count = like_count
        )
        yield item
